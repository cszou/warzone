#pragma once

void testGameStates();
