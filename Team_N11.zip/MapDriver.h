#pragma once

void testLoadMaps();