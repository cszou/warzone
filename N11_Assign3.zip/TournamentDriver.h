#pragma once

void testTournament();