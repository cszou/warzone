#pragma once

void testPlayerStrategies();