#include <string>
#include <iostream>
#ifndef GAME_ENGINE_H
#define GAME_ENGINE_H
using namespace std;
#include "LoggingObserver.h"
#include "Player.h"
#include <vector>
#include "Orders.h"
#include <algorithm>
#include <random>
#include "Utilities.h"
#include "Map.h"
#include <map>
#include <iterator>
using std::vector;


class GameEngine :public ILoggable, public Subject{
private:
	string state;
	string state_start;
	string state_map_loaded;
	string state_map_validated;
	string state_players_added;
	string state_assign_reinforcement;
	string state_issue_orders;
	string state_execute_orders;
	string state_win;
	string state_Terminated;
	Map* gameMap; //Another Map ... ?
	Player* neutralPlayer;
	vector<Player*> playersList;
	Map* map; 
	Deck* deck;
	bool startupFinished;

public:

	GameEngine();
	GameEngine(const GameEngine& copy);
	GameEngine& operator = (const GameEngine& copy);
	string getState();
	void setState(string newState);
	friend ostream& operator << (ostream& out, const GameEngine& gameEngine);
	//define stringToLog method from abstract base class Iloggable
	string stringToLog();
	void addPlayer(string playerName);
	void readMap(string mapName);
	vector<Player*> playerList; // Public playerList ...? 
	Player* getNeutralPlayer();
	void startupPhase();
	void mainGameLoop();
};


#endif
