#pragma once

void testLoggingObserver();
