#pragma once

void testCommandProcessor();