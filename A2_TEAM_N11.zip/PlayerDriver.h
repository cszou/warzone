#pragma once

void testPlayers();